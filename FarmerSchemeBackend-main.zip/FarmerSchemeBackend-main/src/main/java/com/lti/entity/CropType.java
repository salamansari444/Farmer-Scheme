package com.lti.entity;

public enum CropType {
	KHARIF,
	RABI,
	HORTICULTURE;

}
