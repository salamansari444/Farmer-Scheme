package com.lti.service;

import com.lti.entity.Insurance;

public interface InsuranceService {
	Insurance findById(int id); 
}
