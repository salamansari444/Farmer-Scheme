package com.lti.repository;

import com.lti.entity.Insurance;

public interface InsuranceRepo {
	Insurance findById(int id);  
}
